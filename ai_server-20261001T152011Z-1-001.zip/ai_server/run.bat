@echo off
cd /d C:\Users\DARAHAS\ai_server
call venv\Scripts\activate.bat
set GEMINI_API_KEY=PASTE_YOUR_GEMINI_KEY_HERE
python -m uvicorn ai_server:app --host 0.0.0.0 --port 8000 --reload
pause